<?php
include (__DIR__."/header.php");

$description = " ";
$example_description = " ";

?>

<?php
include (__DIR__."/content.php");
?>

<?php
include (__DIR__."/trailer.php");
?>
