<?php
namespace Reportico\Engine;
$translations = array (
		"fr_fr" => array (
			"Source String" => "Translation"
			),
		"fr_fr" => array (
			"Source String" => "Translation"
			),
		);

$report_desc = array ( 
        "fr_fr" => array (
		"reportdefinition.xml" => 
        "Translated description"
			)
		);
ReporticoApp::set("translations", $translations);
ReporticoApp::set("report_desc", $report_desc);
?>
